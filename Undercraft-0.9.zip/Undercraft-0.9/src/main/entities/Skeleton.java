package main.entities;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Skeleton {

    private int x, y;
    private Player player;
    private int speed = 1;

    private long lastDamageTime = 0;
    private long damageInterval = 1000;
    private long lastArrowShotTime = 0;
    private long arrowInterval = 2000;
    private final int minArrowInterval = 1000;
    private final int maxArrowInterval = 2000;
    private Random random = new Random();
    
    public boolean isDead = false;
    private int health = 5;
    private List<Arrow> arrows;
    private boolean isPreparingToShoot = false;
    private long preparationEndTime = 0;
    private long preparationDuration = 1000;

    private List<Skeleton> skeletons; // Lista de esqueletos para detectar colisiones

    public Skeleton(int x, int y, Player player, List<Skeleton> skeletons) {
        this.x = x;
        this.y = y;
        this.player = player;
        this.arrows = new ArrayList<>();
        this.skeletons = skeletons; // Recibe la lista de todos los esqueletos
    }

    public void update() {
        long currentTime = System.currentTimeMillis();

        if (isPreparingToShoot) {
            if (currentTime >= preparationEndTime) {
                shootArrow();
                lastArrowShotTime = currentTime;
                isPreparingToShoot = false;
                arrowInterval = minArrowInterval + random.nextInt(maxArrowInterval - minArrowInterval);
            }
        } else {
            if (x < player.getX()) {
                x += speed;
            } else if (x > player.getX()) {
                x -= speed;
            }

            if (currentTime - lastArrowShotTime >= arrowInterval) {
                isPreparingToShoot = true;
                preparationEndTime = currentTime + preparationDuration;
            }
        }

        for (int i = 0; i < arrows.size(); i++) {
            Arrow arrow = arrows.get(i);
            arrow.update();

            if (arrow.isOutOfBounds()) {
                arrows.remove(i);
                i--;
            }
        }

        if (isCollidingWithPlayer()) {
            if (currentTime - lastDamageTime >= damageInterval) {
                player.vida--;
                lastDamageTime = currentTime;
            }
        }

        // Ya no es necesario llamar a checkCollisionWithSkeletons aquí
        // Solo aplicamos colisiones al recibir daño
    }


    public void draw(Graphics g) {
        g.setColor(Color.gray);
        g.fillRect(x, y, 64, 64);

        for (Arrow arrow : arrows) {
            arrow.draw(g);
        }
    }

    private boolean isCollidingWithPlayer() {
        int playerWidth = player.getWidth();
        int playerHeight = player.getHeight();

        return (x < player.getX() + playerWidth && x + 64 > player.getX() &&
                y < player.getY() + playerHeight && y + 64 > player.getY());
    }

    private void shootArrow() {
        boolean movingRight = player.getX() > x;
        arrows.add(new Arrow(x, y + 32, movingRight, player));
    }

    public void takeDamage() {
        if (health > 0) {
            health--;
            if (health <= 0) {
                die();
            } else {
                applyKnockback(); // Aplicar retroceso al recibir daño
            }
        }
    }

    private void applyKnockback() {
        int knockbackDistance = 20;

        if (x < player.getX()) {
            x -= knockbackDistance; // Retroceso hacia la izquierda
        } else {
            x += knockbackDistance; // Retroceso hacia la derecha
        }

        // Verificar colisión con otros esqueletos
        checkCollisionWithSkeletonsKnockback(knockbackDistance / 2);
    }

    private void checkCollisionWithSkeletonsKnockback(int secondaryKnockback) {
        for (Skeleton other : skeletons) {
            if (other != this && isCollidingWithSkeleton(other)) {
                if (x < other.x) {
                    other.x += secondaryKnockback; // Empujar a la derecha
                } else {
                    other.x -= secondaryKnockback; // Empujar a la izquierda
                }
            }
        }
    }

    private boolean isCollidingWithSkeleton(Skeleton other) {
        return (x < other.x + 64 && x + 64 > other.x &&
                y < other.y + 64 && y + 64 > other.y);
    }

    private void die() {
        isDead = true;
    }

    public boolean isDead() {
        return isDead;
    }
    
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
    
    public int getWidth() {
        return 64;
    }
    
    public int getHeight() {
        return 64;
    }
}
