package main.entities;

import java.awt.Graphics;
import java.awt.Image;

import main.ui.Window;

public class EnderDragon {
    public int x, y;
    private Image enderDragonImageLeft;  // Imagen cuando el zombie va hacia la izquierda
    private Image enderDragonImageRight; // Imagen cuando el zombie va hacia la derecha
    private Player player;
    private int width = 64;  // Ancho del zombie
    private int height = 64; // Alto del zombie
    
    private long lastDamageTime = 0;
    private long damageInterval = 1000;
    public boolean isDead = false;
    private int health = 3;
    private int estadoX = 0;
    private int estadoY = 0;
    private int countReposo = 0;
    private int j = 0;
    private int movX = 700;
    private int movY = 400;

    private boolean movingRight = true; // Indica si el zombie está yendo a la derecha
    
	public EnderDragon(int x, int y, Player player, Image enderDragonImageLeft, Image enderDragonImageRight) {
        this.x = x;
        this.y = y;
        this.player = player;
        this.enderDragonImageLeft = enderDragonImageLeft;
        this.enderDragonImageRight = enderDragonImageRight;
	}
	
    public void update() {
        // Movimiento hacia el jugador en el eje X
    	
    	x = movX;
    	y = movY;
    	
		if(movX == 400) {
			countReposo++;
		}
		if(countReposo == 8) {
			do {
				if(Window.delta >= 1) {
					j++;
				}
				movX = 400;
				movY = 375;
			}	while(j <= 5);
		}
    	
	    if(movX <= 850 && estadoX == 0) {
	    	movX += 3;
	    }
	    
	    else {
	    	estadoX = 1;
	    	movX -= 3;
	    	
	    	if(movX == 31) {
	    		estadoX = 0;
	    	}
	    }
	    
	    if(movY >= 320 && estadoY == 0) {
	    	movY -= 3;
	    }
	    
	    else {
	    	estadoY = 1;
	    	movY += 3;
	    	
	    	if(movY == 402) {
	    		estadoY = 0;
	    	}
	    }

        // Detectar si colisiona con el jugador
        if (isCollidingWithPlayer()) {
            long currentTime = System.currentTimeMillis();
            
            if (currentTime - lastDamageTime >= damageInterval && player.vida > 0) {
                player.vida--; // Reducir la vida del jugador
                lastDamageTime = currentTime;
            }
        }

    }
    
    public void draw(Graphics g) {
        if (health > 0) {
            // Dibujar la imagen correspondiente dependiendo de la dirección
            if (movingRight) {
                g.drawImage(enderDragonImageRight, x, y, null);
            } else {
                g.drawImage(enderDragonImageLeft, x, y, null);
            }
        }
    }

    // Método para detectar colisión con el jugador
    private boolean isCollidingWithPlayer() {
        int playerWidth = player.getWidth();
        int playerHeight = player.getHeight();
        
        return (x < player.x + playerWidth && x + width > player.x &&
                y < player.y + playerHeight && y + height > player.y);
    }

}
